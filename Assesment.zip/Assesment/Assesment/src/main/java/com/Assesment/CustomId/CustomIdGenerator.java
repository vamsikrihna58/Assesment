package com.Assesment.CustomId;

import java.util.UUID;

import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.IdentifierGenerator;

public class CustomIdGenerator implements IdentifierGenerator {
  static int a=0;
	@Override
	public Object generate(SharedSessionContractImplementor session, Object object) {
		
		return ("CL"+ ++a).toString();
	}

}
