package com.Assesment.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Assesment.BaseRepository.ClientRepo;
import com.Assesment.Entity.ClientEntity;

@Service
public class ServiceClass {
	
	@Autowired
	private ClientRepo cr;
	

	public String addData(ClientEntity ce) {
		cr.addData(ce);
		 return "added";
		
	}
	public List<ClientEntity> alData() {
		return cr.alData();
	}
	public String Updated(ClientEntity ce) {
		cr.Updated(ce);
		return "updated";
	}
	public String delete(String id) {
		cr.delete(id);
		return "deleted";
	}public ClientEntity getById(String id) {
		
		return cr.getById(id);
	}
	public List<ClientEntity> getEntity(String s) {
		return cr.getEntity(s);
	}
	
	

}
