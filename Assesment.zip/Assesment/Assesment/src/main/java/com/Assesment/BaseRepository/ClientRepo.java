package com.Assesment.BaseRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.Assesment.Entity.ClientEntity;

@Repository
public class ClientRepo {

	@Autowired
	private ClientRepository cr;

	public String addData(ClientEntity ce) {
		String name = ce.getCname().toLowerCase();
		ce.setCname(name);
		cr.save(ce);
		return "added";

	}

	public List<ClientEntity> alData() {
		return cr.findAll();
	}

	public String Updated(ClientEntity ce) {
		cr.save(ce);
		return "updated";
	}

	public String delete(String id) {
		cr.deleteById(id);
		return "deleted";
	}

	public ClientEntity getById(String id) {
		Optional<ClientEntity> byId = cr.findById(id);
		return byId.get();
	}

	public List<ClientEntity> getEntity(String s) {
        List<ClientEntity> re=new ArrayList<>();
		Optional<ClientEntity> byId = cr.findById(s);
		if (byId.isPresent()) {
			 re.add(byId.get());
			 return re;
		    
		}
		else {
			return cr.findByCname(s);
			
		}
		

	}

}
