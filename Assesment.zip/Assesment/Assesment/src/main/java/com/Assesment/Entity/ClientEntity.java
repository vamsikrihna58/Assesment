package com.Assesment.Entity;

import java.io.Serializable;
import java.util.Date;

import org.hibernate.annotations.GenericGenerator;

import com.Assesment.CustomId.CustomIdGenerator;
import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import lombok.Getter;
import lombok.Setter;

@Entity

public class ClientEntity implements Serializable{

	@Id
	@GeneratedValue(generator = "vamsi")
	@GenericGenerator(name="vamsi",type = CustomIdGenerator.class)
	private String id;
	private String cname;
	private String cphone;
	
	private String rDate;
	private String iRecieved;
	
	private String data;
	
	private String risuue;
	@Override
	public String toString() {
		return "ClientEntity [id=" + id + ", cname=" + cname + ", cphone=" + cphone + ", rDate=" + rDate
				+ ", iRecieved=" + iRecieved + ", data=" + data + ", risuue=" + risuue + ", cNotes=" + cNotes
				+ ", atechie=" + atechie + ", deadLine=" + deadLine + ", amount=" + amount + ", status=" + status + "]";
	}
	private String cNotes;
	private String atechie;
	
	private String deadLine;
	
	private String amount;
	private String status;
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the cname
	 */
	public String getCname() {
		return cname;
	}
	/**
	 * @param cname the cname to set
	 */
	public void setCname(String cname) {
		this.cname = cname;
	}
	/**
	 * @return the cphone
	 */
	public String getCphone() {
		return cphone;
	}
	/**
	 * @param cphone the cphone to set
	 */
	public void setCphone(String cphone) {
		this.cphone = cphone;
	}
	/**
	 * @return the rDate
	 */
	
	/**
	 * @return the iRecieved
	 */
	public String getiRecieved() {
		return iRecieved;
	}
	/**
	 * @param iRecieved the iRecieved to set
	 */
	public void setiRecieved(String iRecieved) {
		this.iRecieved = iRecieved;
	}
	/**
	 * @return the data
	 */
	public String getData() {
		return data;
	}
	/**
	 * @param data the data to set
	 */
	public void setData(String data) {
		this.data = data;
	}
	/**
	 * @return the risuue
	 */
	public String getRisuue() {
		return risuue;
	}
	/**
	 * @param risuue the risuue to set
	 */
	public void setRisuue(String risuue) {
		this.risuue = risuue;
	}
	/**
	 * @return the cNotes
	 */
	public String getcNotes() {
		return cNotes;
	}
	/**
	 * @param cNotes the cNotes to set
	 */
	public void setcNotes(String cNotes) {
		this.cNotes = cNotes;
	}
	/**
	 * @return the atechie
	 */
	public String getAtechie() {
		return atechie;
	}
	/**
	 * @param atechie the atechie to set
	 */
	public void setAtechie(String atechie) {
		this.atechie = atechie;
	}
	/**
	 * @return the deadLine
	 */
	

	public String getAmount() {
		return amount;
	}
	
	/**
	 * @return the rDate
	 */
	public String getrDate() {
		return rDate;
	}
	/**
	 * @param rDate the rDate to set
	 */
	public void setrDate(String rDate) {
		this.rDate = rDate;
	}
	/**
	 * @return the deadLine
	 */
	public String getDeadLine() {
		return deadLine;
	}
	/**
	 * @param deadLine the deadLine to set
	 */
	public void setDeadLine(String deadLine) {
		this.deadLine = deadLine;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	
	
	
	

}
