package com.Assesment.BaseRepository;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;

import com.Assesment.Entity.ClientEntity;

interface ClientRepository extends JpaRepository<ClientEntity, String>{
	
	List<ClientEntity> findByCname(String name);

}
