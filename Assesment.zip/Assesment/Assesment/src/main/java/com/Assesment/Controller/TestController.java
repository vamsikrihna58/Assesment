package com.Assesment.Controller;

import java.util.List;


import java.util.Optional;

import org.apache.coyote.http11.Http11InputBuffer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Assesment.Entity.ClientEntity;


import com.Assesment.Service.ServiceClass;

@RestController
@CrossOrigin(origins = "null")
public class TestController {

	@Autowired
	private ServiceClass sc;
	
// By calling of this request we will save the client details in database
	@PostMapping("save")
	public String addData(@RequestBody ClientEntity ce) {
		ce.setCname(ce.getCname().toUpperCase());
		sc.addData(ce);

		return "added";

	}
// By calling this request we will gert the details fo all clients
	@GetMapping("All")
	public List<ClientEntity> alData() {
		return sc.alData();
	}
// By calling of this request we will update the Client deatils
	@PostMapping("updated")
	public String Updated(@RequestBody ClientEntity ce) {
		sc.Updated(ce);
		return "updated";
	}
// By calling this requestr we will delete the client data from our database
	@DeleteMapping("deleted/{id}")
	public String delete(@PathVariable String id) {
		sc.delete(id);
		return "deleted";
	}
//By using this we will get specific client data based on thier Id 
	@GetMapping("get/{id}")
	public ClientEntity getById(@PathVariable String id) {

		return sc.getById(id);
	}
//By using this we will get specific client data based on thier Id or their name
	@GetMapping("search/{input}")
	public List<ClientEntity> getEntity(@PathVariable String input) {
	  List<ClientEntity> entity = sc.getEntity(input);
	 return entity;
	
	 
		
	}

}
